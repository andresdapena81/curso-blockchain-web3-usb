/**
 * Laboratorio Tokens y NFT (S10 + S11) · configuración mínima.
 * Todo corre en la red simulada de Hardhat: sin redes externas, sin claves,
 * sin ETH. Versiones congeladas del curso (ver package.json).
 */
import toolbox from "@nomicfoundation/hardhat-toolbox-mocha-ethers";

export default {
  plugins: [toolbox],
  solidity: {
    version: "0.8.34",
    settings: { optimizer: { enabled: true, runs: 200 } },
  },
};
