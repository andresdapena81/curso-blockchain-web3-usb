# Laboratorio · Tokens y NFT (S10 + S11)

Blockchain y Web 3.0 · USB Medellín · Unidad III

Dos laboratorios encadenados que se hacen **en grupo, en clase**. Todo corre
en la **red local de Hardhat**: no se necesita ETH de prueba, ni una red
pública, ni IPFS. La evidencia es la captura de las **pruebas en verde**.

**La rúbrica completa (pesos y qué se evalúa) está en `guias/rubrica.pdf`.**

- **Lab 1 · Token ERC-20** — `FichaUSB` (token con tope y quema) + `Canje`
  (el patrón `approve` + `transferFrom`). Meta: **12 pruebas en verde**.
- **Lab 2 · NFT** — `DiplomaUSB` (credencial ERC-721) + `DiplomaSBT` (el mismo
  diploma, pero **intransferible**, ERC-5192). Meta: **20 pruebas en verde**.

---

## Requisitos

- **Node 22 LTS** o superior (`node --version`).
- Nada más: ni ETH, ni red pública, ni cuentas externas.

## Instalación

Desde una terminal, dentro de esta carpeta:

```bash
npm install
```

## Cómo correr las pruebas

```bash
npm run ficha      # Lab 1 · token ERC-20 (test/s10/FichaUSB.test.js)
npm run diploma    # Lab 2 · NFT y SBT   (test/s11/DiplomaUSB.test.js + DiplomaSBT.test.js)
```

> `npx hardhat test` recibe **archivos**, no carpetas.

Al empezar, las pruebas marcadas con ★ **fallan a propósito**: son los `// TODO`
que ustedes completan. A medida que escriben bien cada pieza, pasan a verde.

---

## Qué trae el paquete

```
contracts/s10/   FichaUSB.sol, Canje.sol          ← Lab 1 · con los TODO 1–4
contracts/s11/   DiplomaUSB.sol, DiplomaSBT.sol    ← Lab 2 · con sus TODO
test/s10/        FichaUSB.test.js                  ← 12 pruebas (no se tocan)
test/s11/        DiplomaUSB.test.js, DiplomaSBT.test.js   ← 20 pruebas (no se tocan)
guias/           s10-token-erc20.pdf, s11-diploma-nft-ipfs.pdf, rubrica.pdf
```

Los contratos **compilan tal como están**; lo que falta son los `// TODO`.
Cada TODO está explicado en el contrato y en la **guía PDF** correspondiente.

## Orden sugerido

**Lab 1 (token):**
1. TODO 1 · el tope (convertir con `decimals()`).
2. TODO 2 · `acunar` (`_mint`).
3. TODO 3 · `_update` (una línea: `super._update(...)`). **Empiecen por este:**
   mientras esté vacío, ninguna transferencia mueve saldos.
4. TODO 4 · `canjear()` (`transferFrom`, el patrón de aprobación).

**Lab 2 (NFT):**
1. `DiplomaUSB.emitir()` — checks, effects, interaction (TODO 1–3) y
   `totalEmitidos()` (TODO 4).
2. `DiplomaSBT` (reto opcional) — `locked`, `revocar` y el `if` en `_update`
   que bloquea la transferencia.

## Qué se entrega

1. `FichaUSB.sol`, `Canje.sol`, `DiplomaUSB.sol` (y `DiplomaSBT.sol` si hicieron
   el reto) completos.
2. Captura de la terminal con las **pruebas en verde** de los dos labs.
3. El informe corto con las preguntas que trae cada contrato respondidas (qué
   evento estándar emite `emitir()`, por qué `canjear()` no necesita un
   `require` sobre la allowance, por qué el contrato no compila sin los
   `override`).

## Reglas

- **No modifiquen** los archivos de `test/`: son su calificación.
- Trabajen sobre los contratos de `contracts/`: el objetivo es **completar los
  TODO**, no cambiar las pruebas.
- Material de clase **sin auditar**: solo red local, nunca dinero real.
- Pueden usar IA **declarándola**; la parte de informe mide su criterio.
