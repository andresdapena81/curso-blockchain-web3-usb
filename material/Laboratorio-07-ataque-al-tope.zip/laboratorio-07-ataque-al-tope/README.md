# Laboratorio 07 · ¿Se puede rodear el tope de reventa?

**Blockchain y Web 3.0 · Universidad de San Buenaventura Medellín**

El encargo cabe en una línea:

> **Revendan una entrada por encima del tope.**

El contrato que van a atacar es real: es el proyecto del docente, publicado en
[github.com/andresdapena81/entradas-reventa-controlada](https://github.com/andresdapena81/entradas-reventa-controlada).
Promete que el tope de reventa no es un término y condiciones, sino una regla
que no se puede incumplir. Su trabajo de hoy es averiguar si eso es cierto.

---

## Qué hay aquí

```
contracts/s07/
├── EntradasVulnerable.sol   ← el contrato que van a leer y atacar
├── Entradas.sol             ← la versión corregida (NO abrir todavía: ver la guía)
├── AtacanteTope.sol         un revendedor que programa su propio contrato
└── AtacanteCompuerta.sol    la prueba de concepto del reto final
test/s07/
├── AtaqueAlTope.test.js     11 pruebas: cinco intentos de rodear el tope
└── CompuertaAbierta.test.js  4 pruebas: el mismo ataque contra las dos versiones
guias/
├── s07-ataque-al-tope.pdf      la guía del laboratorio · empiecen por aquí
└── ficha-lectura-contrato.pdf  para imprimir y llenar a mano
```

**`Entradas.sol` lleva la respuesta en sus comentarios.** Si lo abren antes de
tiempo, se arruinan el laboratorio. La guía dice exactamente cuándo abrirlo.

---

## Cómo ponerlo a andar

### Si ya tienen el proyecto del curso clonado

Copien las carpetas `contracts/s07` y `test/s07` sobre su copia de
`material/laboratorios-evm`, y listo. No hace falta instalar nada más.

### Si prefieren trabajar con esta carpeta sola

Necesitan **Node.js 22 LTS**. Una sola vez:

```bash
npm install
```

Y después, cada vez:

```bash
npx hardhat test test/s07/AtaqueAlTope.test.js test/s07/CompuertaAbierta.test.js
```

o, más corto, `npm run probar`.

**Lo que tienen que ver:** `15 passing`. Todo corre en una red simulada que
Hardhat levanta sola. No hace falta billetera, ni red de prueba, ni un peso.

---

## El orden de la tarde

1. **Lean el contrato** con las cuatro pasadas y llenen la ficha. Sin correr nada.
2. **Corran las pruebas** y vean los cinco intentos: cuatro se estrellan y uno
   revela el límite de lo que un contrato puede hacer cumplir.
3. **Paren a escribir** cuando la guía se los pida. Hay dos paradas, y están
   puestas a propósito antes de las dos respuestas.
4. **El reto final:** un ataque que sí rompe la promesa del contrato. Explíquenlo
   con sus palabras y escriban una prueba de regresión propia.

La guía lleva el detalle de cada paso, la tabla de errores frecuentes y la
rúbrica con la que se califica.

---

## Lo que se entrega

| Qué | Dónde |
|---|---|
| La ficha de lectura, llena | En papel, al final de la sesión |
| Su explicación del fallo y de la corrección | Máximo media página |
| Su prueba de regresión | Un archivo `.test.js` que pase contra la versión corregida y falle contra la vulnerable |

Opcional, suma: un sexto intento de ataque inventado por ustedes, con su prueba,
demuestre o no que funciona.

---

## Advertencias

- Todo ocurre en la **red simulada de Hardhat**. Nunca con dinero real.
- Los contratos son **material de clase, sin auditar**.
- `EntradasVulnerable.sol` tiene un fallo **a propósito**. No lo copien a ningún
  proyecto propio: el que sirve de referencia es `Entradas.sol`.
