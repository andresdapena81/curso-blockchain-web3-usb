/**
 * Laboratorio 07 · configuración mínima
 *
 * Las mismas versiones congeladas del curso. Todo el laboratorio corre en la
 * red simulada que Hardhat levanta sola: no hace falta ninguna red externa,
 * ninguna clave y ningún peso.
 */
import toolbox from "@nomicfoundation/hardhat-toolbox-mocha-ethers";

export default {
  plugins: [toolbox],
  solidity: {
    version: "0.8.34",
    settings: { optimizer: { enabled: true, runs: 200 } },
  },
};
