"""
Laboratorio 02 · Parte 1 y 2 — SOLUCIÓN DEL DOCENTE
Claves, firmas, dirección y checksum EIP-55.
Blockchain y Web 3.0 · Universidad de San Buenaventura Medellín
"""

import hashlib
from typing import Tuple

from ecdsa import SigningKey, VerifyingKey, SECP256k1, BadSignatureError
from Crypto.Hash import keccak


# =====================================================================
# CONVENCIONES DEL LABORATORIO
#   1. La clave privada son 32 bytes; la pública, 64 (X || Y, SIN el
#      byte de prefijo de formato). Ese prefijo es la causa número uno
#      de que la dirección no coincida.
#   2. Se firma sobre el hash SHA-256 del mensaje.
#   3. La dirección son los ÚLTIMOS 20 bytes de keccak256(pública).
# =====================================================================


def keccak256(datos: bytes) -> bytes:
    """Keccak-256, la variante que usa Ethereum. NO es SHA3-256.

    Ya viene resuelta: nunca se implementa criptografía a mano.
    Vector de comprobación: keccak256(b"") empieza por c5d2460186f7233c.
    """
    h = keccak.new(digest_bits=256)
    h.update(datos)
    return h.digest()


# --------------------------------------------------------------- PARTE 1
def generar_par() -> Tuple[bytes, bytes]:
    """Genera un par de claves sobre secp256k1.

    Devuelve (privada, publica): 32 y 64 bytes respectivamente.
    La aleatoriedad la aporta la biblioteca desde la fuente segura del
    sistema operativo. Nunca se usa el generador de azar de propósito
    general del lenguaje.
    """
    sk = SigningKey.generate(curve=SECP256k1)
    return sk.to_string(), sk.get_verifying_key().to_string()


def firmar(privada: bytes, mensaje: bytes) -> bytes:
    """Firma ECDSA del mensaje. Devuelve 64 bytes: r || s."""
    sk = SigningKey.from_string(privada, curve=SECP256k1)
    return sk.sign(mensaje, hashfunc=hashlib.sha256)


def verificar(publica: bytes, mensaje: bytes, firma: bytes) -> bool:
    """¿La firma corresponde a ese mensaje y a esa clave pública?

    Devuelve False —no lanza excepción— ante cualquier fallo: firma
    inválida, mensaje alterado, clave equivocada o firma malformada.
    """
    try:
        vk = VerifyingKey.from_string(publica, curve=SECP256k1)
        return vk.verify(firma, mensaje, hashfunc=hashlib.sha256)
    except (BadSignatureError, Exception):
        return False


# --------------------------------------------------------------- PARTE 2
def direccion_desde_publica(publica: bytes) -> str:
    """Dirección de 20 bytes en hexadecimal, sin prefijo 0x.

    keccak256 de los 64 bytes de la clave pública; se conservan los
    últimos 20 y se descartan los 12 primeros.
    """
    if len(publica) != 64:
        raise ValueError("La clave pública debe tener 64 bytes (X || Y, sin prefijo)")
    return keccak256(publica)[-20:].hex()


def a_eip55(direccion_hex: str) -> str:
    """Aplica el checksum de EIP-55 sobre una dirección hexadecimal.

    Se hashea la dirección en minúsculas; para cada carácter, si es
    letra y el dígito correspondiente del hash es 8 o mayor, se pone
    en mayúscula.
    """
    d = direccion_hex.lower().removeprefix("0x")
    h = keccak256(d.encode("ascii")).hex()
    return "0x" + "".join(
        c.upper() if (c.isalpha() and int(h[i], 16) >= 8) else c
        for i, c in enumerate(d)
    )


def eip55_valido(direccion: str) -> bool:
    """¿El patrón de mayúsculas de esta dirección es el correcto?

    Una dirección toda en minúsculas o toda en mayúsculas se considera
    "sin checksum" y no se valida aquí: solo se comprueban las mixtas.
    """
    d = direccion.removeprefix("0x")
    if len(d) != 40:
        return False
    letras = [c for c in d if c.isalpha()]
    if not letras or all(c.islower() for c in letras) or all(c.isupper() for c in letras):
        return False                       # sin checksum aplicado
    return a_eip55(d) == "0x" + d
