"""
Laboratorio 02 · Parte 3 — SOLUCIÓN DEL DOCENTE
Transacciones firmadas, bloques y validación de la cadena.
Blockchain y Web 3.0 · Universidad de San Buenaventura Medellín
"""

import hashlib
import json
from dataclasses import dataclass, field
from typing import List, Optional

from cripto import firmar, verificar, direccion_desde_publica
from merkle import raiz_de_merkle


def sha256_hex(datos: bytes) -> str:
    return hashlib.sha256(datos).hexdigest()


# =====================================================================
# TRANSACCIÓN
# =====================================================================
@dataclass
class Transaccion:
    origen: str          # dirección hexadecimal, sin 0x
    destino: str
    monto: int
    contador: int        # el "nonce" por cuenta: impide reenviar la misma tx
    firma: Optional[bytes] = None
    publica: Optional[bytes] = None

    def serializar(self) -> bytes:
        """Representación en bytes, DETERMINISTA.

        Siempre los mismos campos en el mismo orden. Si dos nodos
        serializan distinto calculan hashes distintos y la firma no
        verifica: es el error más común del laboratorio.

        La firma NO forma parte de lo que se firma, evidentemente.
        """
        cuerpo = {
            "origen": self.origen,
            "destino": self.destino,
            "monto": self.monto,
            "contador": self.contador,
        }
        return json.dumps(cuerpo, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def hash(self) -> str:
        return sha256_hex(self.serializar())

    def firmar_con(self, privada: bytes, publica: bytes) -> "Transaccion":
        """Firma la transacción y comprueba que el origen sea coherente."""
        if direccion_desde_publica(publica) != self.origen:
            raise ValueError("La clave pública no corresponde a la dirección de origen")
        self.publica = publica
        self.firma = firmar(privada, self.serializar())
        return self

    def firma_valida(self) -> bool:
        """La firma verifica Y la clave pública corresponde al origen."""
        if self.firma is None or self.publica is None:
            return False
        if direccion_desde_publica(self.publica) != self.origen:
            return False
        return verificar(self.publica, self.serializar(), self.firma)


# =====================================================================
# BLOQUE
# =====================================================================
@dataclass
class Bloque:
    indice: int
    hash_anterior: str
    transacciones: List[Transaccion] = field(default_factory=list)
    marca_temporal: int = 0
    nonce: int = 0

    def raiz_merkle(self) -> str:
        """Raíz de Merkle de las transacciones. Reutiliza el Laboratorio 01."""
        if not self.transacciones:
            return sha256_hex(b"")            # bloque vacío: convención del curso
        return raiz_de_merkle([t.serializar() for t in self.transacciones])

    def cabecera(self) -> bytes:
        """Solo la cabecera se hashea. El cuerpo entra a través de la raíz."""
        h = {
            "indice": self.indice,
            "hash_anterior": self.hash_anterior,
            "raiz_merkle": self.raiz_merkle(),
            "marca_temporal": self.marca_temporal,
            "nonce": self.nonce,
        }
        return json.dumps(h, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def hash(self) -> str:
        """SE RECALCULA SIEMPRE desde la cabecera. Nunca se guarda.

        Guardar el hash y leerlo después es el error conceptual más
        grave de este laboratorio: la cadena validaría aunque se
        hubiera alterado su contenido.
        """
        return sha256_hex(self.cabecera())


# =====================================================================
# VALIDACIÓN
# =====================================================================
def bloque_genesis() -> Bloque:
    return Bloque(indice=0, hash_anterior="0" * 64, transacciones=[], marca_temporal=0)


def cadena_valida(cadena: List[Bloque]) -> tuple:
    """Valida la cadena completa.

    Devuelve (True, "") si es válida, o (False, motivo) con el primer
    fallo encontrado. Devolver el motivo es lo que permite ver EN QUÉ
    ORDEN se rompen las cosas al alterar un bloque.
    """
    if not cadena:
        return False, "cadena vacía"
    if cadena[0].hash_anterior != "0" * 64:
        return False, "el bloque génesis no apunta a cero"

    for i, bloque in enumerate(cadena):
        for j, t in enumerate(bloque.transacciones):
            if not t.firma_valida():
                return False, f"firma inválida en el bloque {i}, transacción {j}"

        if i > 0:
            esperado = cadena[i - 1].hash()
            if bloque.hash_anterior != esperado:
                return False, f"el eslabón del bloque {i} no coincide con el hash real del {i-1}"
            if bloque.indice != cadena[i - 1].indice + 1:
                return False, f"índice fuera de secuencia en el bloque {i}"

    return True, ""


def saldos(cadena: List[Bloque], inicial: dict) -> dict:
    """Aplica todas las transacciones y devuelve los saldos finales.

    Lanza ValueError ante un saldo insuficiente: es la comprobación que
    impide gastar lo que no se tiene.
    """
    s = dict(inicial)
    for bloque in cadena:
        for t in bloque.transacciones:
            if s.get(t.origen, 0) < t.monto:
                raise ValueError(f"saldo insuficiente en {t.origen[:10]}…")
            s[t.origen] = s.get(t.origen, 0) - t.monto
            s[t.destino] = s.get(t.destino, 0) + t.monto
    return s
