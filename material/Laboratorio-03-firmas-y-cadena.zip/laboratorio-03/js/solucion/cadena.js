/**
 * Laboratorio 02 · Parte 3 — SOLUCIÓN DEL DOCENTE
 * Transacciones firmadas, bloques y validación de la cadena.
 * Blockchain y Web 3.0 · Universidad de San Buenaventura Medellín
 */

import { createHash } from "node:crypto";
import { firmar, verificar, direccionDesdePublica } from "./cripto.js";
import { raizDeMerkle } from "./merkle.js";          // viene del Laboratorio 01

export function sha256Hex(datos) {
  return createHash("sha256").update(datos).digest("hex");
}

/** Serialización canónica: claves ordenadas, sin espacios. */
function canonico(obj) {
  const claves = Object.keys(obj).sort();
  return "{" + claves.map((k) => JSON.stringify(k) + ":" + JSON.stringify(obj[k])).join(",") + "}";
}

/* =====================================================================
   TRANSACCIÓN
   ===================================================================== */
export class Transaccion {
  constructor(origen, destino, monto, contador) {
    this.origen = origen;
    this.destino = destino;
    this.monto = monto;
    this.contador = contador;
    this.firma = null;
    this.publica = null;
  }

  /** Determinista: siempre los mismos campos en el mismo orden.
   *  La firma NO entra en lo que se firma. */
  serializar() {
    return Buffer.from(
      canonico({ origen: this.origen, destino: this.destino, monto: this.monto, contador: this.contador }),
      "utf8",
    );
  }

  hash() {
    return sha256Hex(this.serializar());
  }

  firmarCon(privada, publica) {
    if (direccionDesdePublica(publica) !== this.origen) {
      throw new Error("La clave pública no corresponde a la dirección de origen");
    }
    this.publica = publica;
    this.firma = firmar(privada, this.serializar());
    return this;
  }

  firmaValida() {
    if (!this.firma || !this.publica) return false;
    try {
      if (direccionDesdePublica(this.publica) !== this.origen) return false;
    } catch {
      return false;
    }
    return verificar(this.publica, this.serializar(), this.firma);
  }
}

/* =====================================================================
   BLOQUE
   ===================================================================== */
export class Bloque {
  constructor(indice, hashAnterior, transacciones = [], marcaTemporal = 0, nonce = 0) {
    this.indice = indice;
    this.hashAnterior = hashAnterior;
    this.transacciones = transacciones;
    this.marcaTemporal = marcaTemporal;
    this.nonce = nonce;
  }

  raizMerkle() {
    if (this.transacciones.length === 0) return sha256Hex(Buffer.from(""));
    return raizDeMerkle(this.transacciones.map((t) => t.serializar()));
  }

  /** Solo la cabecera se hashea; el cuerpo entra por la raíz de Merkle. */
  cabecera() {
    return Buffer.from(
      canonico({
        indice: this.indice,
        hashAnterior: this.hashAnterior,
        raizMerkle: this.raizMerkle(),
        marcaTemporal: this.marcaTemporal,
        nonce: this.nonce,
      }),
      "utf8",
    );
  }

  /** SE RECALCULA SIEMPRE. Nunca se guarda en una propiedad. */
  hash() {
    return sha256Hex(this.cabecera());
  }
}

/* =====================================================================
   VALIDACIÓN
   ===================================================================== */
export function bloqueGenesis() {
  return new Bloque(0, "0".repeat(64), [], 0);
}

export function cadenaValida(cadena) {
  if (!cadena || cadena.length === 0) return { ok: false, motivo: "cadena vacía" };
  if (cadena[0].hashAnterior !== "0".repeat(64)) {
    return { ok: false, motivo: "el bloque génesis no apunta a cero" };
  }
  for (let i = 0; i < cadena.length; i++) {
    const b = cadena[i];
    for (let j = 0; j < b.transacciones.length; j++) {
      if (!b.transacciones[j].firmaValida()) {
        return { ok: false, motivo: `firma inválida en el bloque ${i}, transacción ${j}` };
      }
    }
    if (i > 0) {
      if (b.hashAnterior !== cadena[i - 1].hash()) {
        return { ok: false, motivo: `el eslabón del bloque ${i} no coincide con el hash real del ${i - 1}` };
      }
      if (b.indice !== cadena[i - 1].indice + 1) {
        return { ok: false, motivo: `índice fuera de secuencia en el bloque ${i}` };
      }
    }
  }
  return { ok: true, motivo: "" };
}

export function saldos(cadena, inicial) {
  const s = { ...inicial };
  for (const b of cadena) {
    for (const t of b.transacciones) {
      if ((s[t.origen] ?? 0) < t.monto) {
        throw new Error(`saldo insuficiente en ${t.origen.slice(0, 10)}…`);
      }
      s[t.origen] = (s[t.origen] ?? 0) - t.monto;
      s[t.destino] = (s[t.destino] ?? 0) + t.monto;
    }
  }
  return s;
}
