/**
 * Laboratorio 02 · Parte 1 y 2 — SOLUCIÓN DEL DOCENTE
 * Claves, firmas, dirección y checksum EIP-55.
 * Blockchain y Web 3.0 · Universidad de San Buenaventura Medellín
 */

import { createHash, createSign, createVerify, generateKeyPairSync, createPublicKey, createPrivateKey } from "node:crypto";
import pkg from "js-sha3";
const { keccak256: keccakHex } = pkg;

/* =====================================================================
   CONVENCIONES
     1. La privada son 32 bytes; la pública, 64 (X || Y, SIN prefijo).
     2. Se firma sobre SHA-256 del mensaje, con codificación cruda
        (r || s) en lugar de DER.
     3. La dirección son los ÚLTIMOS 20 bytes de keccak256(pública).
   ===================================================================== */

export function keccak256(datos) {
  return Buffer.from(keccakHex.arrayBuffer(datos));
}

/* Conversión entre los 32/64 bytes crudos y el formato que espera node. */
function privadaAKeyObject(privada) {
  // DER de una clave privada EC secp256k1, con la clave incrustada.
  const der = Buffer.concat([
    Buffer.from("302e0201010420", "hex"), privada,
    Buffer.from("a00706052b8104000a", "hex"),
  ]);
  return createPrivateKey({ key: der, format: "der", type: "sec1" });
}

function publicaAKeyObject(publica) {
  const der = Buffer.concat([
    Buffer.from("3056301006072a8648ce3d020106052b8104000a034200", "hex"),
    Buffer.from([0x04]), publica,
  ]);
  return createPublicKey({ key: der, format: "der", type: "spki" });
}

/* --------------------------------------------------------------- PARTE 1 */
export function generarPar() {
  const { privateKey, publicKey } = generateKeyPairSync("ec", { namedCurve: "secp256k1" });
  const privDer = privateKey.export({ format: "der", type: "sec1" });
  const privada = privDer.subarray(7, 39);                    // los 32 bytes crudos
  const pubDer = publicKey.export({ format: "der", type: "spki" });
  const publica = pubDer.subarray(pubDer.length - 64);        // X || Y, sin el 0x04
  return { privada: Buffer.from(privada), publica: Buffer.from(publica) };
}

export function firmar(privada, mensaje) {
  const s = createSign("sha256");
  s.update(mensaje);
  s.end();
  return s.sign({ key: privadaAKeyObject(privada), dsaEncoding: "ieee-p1363" });
}

export function verificar(publica, mensaje, firma) {
  try {
    const v = createVerify("sha256");
    v.update(mensaje);
    v.end();
    return v.verify({ key: publicaAKeyObject(publica), dsaEncoding: "ieee-p1363" }, firma);
  } catch {
    return false;
  }
}

/* --------------------------------------------------------------- PARTE 2 */
export function direccionDesdePublica(publica) {
  if (publica.length !== 64) {
    throw new Error("La clave pública debe tener 64 bytes (X || Y, sin prefijo)");
  }
  return keccak256(publica).subarray(-20).toString("hex");
}

export function aEip55(direccionHex) {
  const d = direccionHex.toLowerCase().replace(/^0x/, "");
  const h = keccakHex(d);
  let out = "";
  for (let i = 0; i < d.length; i++) {
    const c = d[i];
    out += /[a-f]/.test(c) && parseInt(h[i], 16) >= 8 ? c.toUpperCase() : c;
  }
  return "0x" + out;
}

export function eip55Valido(direccion) {
  const d = direccion.replace(/^0x/, "");
  if (d.length !== 40) return false;
  const letras = d.split("").filter((c) => /[a-fA-F]/.test(c));
  if (letras.length === 0) return false;
  const todasMin = letras.every((c) => c === c.toLowerCase());
  const todasMay = letras.every((c) => c === c.toUpperCase());
  if (todasMin || todasMay) return false;         // sin checksum aplicado
  return aEip55(d) === "0x" + d;
}
